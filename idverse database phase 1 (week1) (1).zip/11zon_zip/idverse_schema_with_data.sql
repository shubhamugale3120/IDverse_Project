--
-- PostgreSQL database dump
--

-- Dumped from database version 17.5
-- Dumped by pg_dump version 17.5

-- Started on 2025-08-14 23:52:14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 224 (class 1259 OID 16431)
-- Name: documents; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.documents (
    id integer NOT NULL,
    user_id integer,
    doc_type character varying(50),
    ipfs_hash character varying(255),
    uploaded_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.documents OWNER TO postgres;

--
-- TOC entry 223 (class 1259 OID 16430)
-- Name: documents_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.documents_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.documents_id_seq OWNER TO postgres;

--
-- TOC entry 4934 (class 0 OID 0)
-- Dependencies: 223
-- Name: documents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.documents_id_seq OWNED BY public.documents.id;


--
-- TOC entry 220 (class 1259 OID 16409)
-- Name: schemes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.schemes (
    id integer NOT NULL,
    name character varying(100),
    type character varying(50),
    description text,
    eligibility_rules text
);


ALTER TABLE public.schemes OWNER TO postgres;

--
-- TOC entry 219 (class 1259 OID 16408)
-- Name: schemes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.schemes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.schemes_id_seq OWNER TO postgres;

--
-- TOC entry 4935 (class 0 OID 0)
-- Dependencies: 219
-- Name: schemes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.schemes_id_seq OWNED BY public.schemes.id;


--
-- TOC entry 218 (class 1259 OID 16399)
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id integer NOT NULL,
    name character varying(100),
    dob date,
    idverse_number character varying(20),
    email character varying(100),
    phone character varying(15),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.users OWNER TO postgres;

--
-- TOC entry 217 (class 1259 OID 16398)
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO postgres;

--
-- TOC entry 4936 (class 0 OID 0)
-- Dependencies: 217
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- TOC entry 222 (class 1259 OID 16418)
-- Name: wallet_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.wallet_logs (
    id integer NOT NULL,
    user_id integer,
    benefit_type character varying(50),
    amount numeric(10,2),
    "timestamp" timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.wallet_logs OWNER TO postgres;

--
-- TOC entry 221 (class 1259 OID 16417)
-- Name: wallet_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.wallet_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.wallet_logs_id_seq OWNER TO postgres;

--
-- TOC entry 4937 (class 0 OID 0)
-- Dependencies: 221
-- Name: wallet_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.wallet_logs_id_seq OWNED BY public.wallet_logs.id;


--
-- TOC entry 4762 (class 2604 OID 16434)
-- Name: documents id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.documents ALTER COLUMN id SET DEFAULT nextval('public.documents_id_seq'::regclass);


--
-- TOC entry 4759 (class 2604 OID 16412)
-- Name: schemes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schemes ALTER COLUMN id SET DEFAULT nextval('public.schemes_id_seq'::regclass);


--
-- TOC entry 4757 (class 2604 OID 16402)
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- TOC entry 4760 (class 2604 OID 16421)
-- Name: wallet_logs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.wallet_logs ALTER COLUMN id SET DEFAULT nextval('public.wallet_logs_id_seq'::regclass);


--
-- TOC entry 4928 (class 0 OID 16431)
-- Dependencies: 224
-- Data for Name: documents; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.documents (id, user_id, doc_type, ipfs_hash, uploaded_at) FROM stdin;
1	1	Aadhaar Card	QmXYZ1234abcdef	2025-08-08 13:30:31.835865
2	2	Voter ID	QmABC5678ghijkl	2025-08-08 13:30:31.835865
\.


--
-- TOC entry 4924 (class 0 OID 16409)
-- Dependencies: 220
-- Data for Name: schemes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.schemes (id, name, type, description, eligibility_rules) FROM stdin;
1	Scholarship Yojana	Education	Scholarship for students under 25	age < 25 AND enrolled = true
2	Kisan Samman Nidhi	Agriculture	Support for small farmers	farmer = true
\.


--
-- TOC entry 4922 (class 0 OID 16399)
-- Dependencies: 218
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, name, dob, idverse_number, email, phone, created_at) FROM stdin;
1	Anita Sharma	2000-05-14	IDV-2000-0011-XY22	anita@example.com	9876543210	2025-08-08 13:30:31.835865
2	Ravi Kumar	1995-11-02	IDV-1995-0022-ZZ88	ravi@example.com	9876001100	2025-08-08 13:30:31.835865
\.


--
-- TOC entry 4926 (class 0 OID 16418)
-- Dependencies: 222
-- Data for Name: wallet_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.wallet_logs (id, user_id, benefit_type, amount, "timestamp") FROM stdin;
1	1	Scholarship	5000.00	2025-08-08 13:30:31.835865
2	2	Farmer Support	2000.00	2025-08-08 13:30:31.835865
\.


--
-- TOC entry 4938 (class 0 OID 0)
-- Dependencies: 223
-- Name: documents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.documents_id_seq', 2, true);


--
-- TOC entry 4939 (class 0 OID 0)
-- Dependencies: 219
-- Name: schemes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.schemes_id_seq', 2, true);


--
-- TOC entry 4940 (class 0 OID 0)
-- Dependencies: 217
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 2, true);


--
-- TOC entry 4941 (class 0 OID 0)
-- Dependencies: 221
-- Name: wallet_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.wallet_logs_id_seq', 2, true);


--
-- TOC entry 4773 (class 2606 OID 16437)
-- Name: documents documents_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_pkey PRIMARY KEY (id);


--
-- TOC entry 4769 (class 2606 OID 16416)
-- Name: schemes schemes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schemes
    ADD CONSTRAINT schemes_pkey PRIMARY KEY (id);


--
-- TOC entry 4765 (class 2606 OID 16407)
-- Name: users users_idverse_number_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_idverse_number_key UNIQUE (idverse_number);


--
-- TOC entry 4767 (class 2606 OID 16405)
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- TOC entry 4771 (class 2606 OID 16424)
-- Name: wallet_logs wallet_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.wallet_logs
    ADD CONSTRAINT wallet_logs_pkey PRIMARY KEY (id);


--
-- TOC entry 4775 (class 2606 OID 16438)
-- Name: documents documents_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- TOC entry 4774 (class 2606 OID 16425)
-- Name: wallet_logs wallet_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.wallet_logs
    ADD CONSTRAINT wallet_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


-- Completed on 2025-08-14 23:52:14

--
-- PostgreSQL database dump complete
--

