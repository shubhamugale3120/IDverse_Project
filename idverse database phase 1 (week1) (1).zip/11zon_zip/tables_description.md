# IDverse Database Tables Description

This document describes the database schema, table purposes, and their data as per the first week of the IDverse project.

## USERS Table

Stores personal information of registered users.

## SCHEMES Table

Contains details about available government schemes and their eligibility.

## WALLET_LOGS Table

Logs the benefits credited to each user’s wallet.

## DOCUMENTS Table

Stores uploaded user documents with IPFS hash for decentralized storage.